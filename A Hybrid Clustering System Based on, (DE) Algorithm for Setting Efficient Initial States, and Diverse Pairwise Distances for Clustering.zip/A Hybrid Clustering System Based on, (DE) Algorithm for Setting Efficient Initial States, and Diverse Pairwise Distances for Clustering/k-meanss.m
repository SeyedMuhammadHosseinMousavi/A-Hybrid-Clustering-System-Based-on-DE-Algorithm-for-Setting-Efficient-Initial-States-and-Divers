%% random 5 cluster(note that random will generate random samples every time so it is diffrent for 
% diffrent clustering method.so use just one random data for alla
% clustering methods and dont generate random data every time.
clear;
lowerbound = 1;
upperbound = 100;
numberofdata=450;
x = (upperbound-lowerbound).*rand(numberofdata,1) + lowerbound;
y = (upperbound-lowerbound).*rand(numberofdata,1) + lowerbound;
data(1:numberofdata,1)=x;
data(1:numberofdata,2)=y;
[idx1,centers1] = kmeans(data,5);
plot(centers1(1,1),centers1(1,2),'ob','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(2,1),centers1(2,2),'or','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(3,1),centers1(3,2),'go','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(4,1),centers1(4,2),'co','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(5,1),centers1(5,2),'mo','MarkerSize',10,'LineWidth',2);
hold on
index1 = find(idx1 == 1);
index2 = find(idx1 == 2);
index3 = find(idx1 == 3);
index4 = find(idx1 == 4);
index5 = find(idx1 == 5);
plot(data(index1,1),data(index1,2),'xb','MarkerSize',3,'LineWidth',2)
plot(data(index2,1),data(index2,2),'xr','MarkerSize',3,'LineWidth',2)
plot(data(index3,1),data(index3,2),'xg','MarkerSize',3,'LineWidth',2)
plot(data(index4,1),data(index4,2),'xc','MarkerSize',3,'LineWidth',2)
plot(data(index5,1),data(index5,2),'xm','MarkerSize',3,'LineWidth',2)
hold off
%% iris 3 cluster
clear;
load fisheriris;
x=meas(1:end,2);
y=meas(1:end,4);
data=x;
data(1:end,2)=y;
%plot the class for 1 and 5 dim
dataset=meas;
datasetsize=size(dataset);
lbl=string(species);
for i=1:datasetsize(1,1)
if lbl(i,1)=='setosa'
    label(i,1)=1;
else if lbl(i,1)=='versicolor'
    label(i,1)=2;
    else if lbl(i,1)=='virginica'
    label(i,1)=3;
end;end;end;end;
for i=1:datasetsize(1,1)
if label(i,1)==1
    plot(dataset(i,2),dataset(i,4),'xb','MarkerSize',3,'LineWidth',2);    hold on;
else if label(i,1)==2
    plot(dataset(i,2),dataset(i,4),'xr','MarkerSize',3,'LineWidth',2);    hold on;
    else if label(i,1)==3
    plot(dataset(i,2),dataset(i,4),'xg','MarkerSize',3,'LineWidth',2);    hold on;
end;end;end;end;
figure;
[idx1,centers1] = kmeans(data,3);
plot(centers1(1,1),centers1(1,2),'ob','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(2,1),centers1(2,2),'or','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(3,1),centers1(3,2),'go','MarkerSize',10,'LineWidth',2);
hold on
index1 = find(idx1 == 1);
index2 = find(idx1 == 2);
index3 = find(idx1 == 3);
plot(data(index1,1),data(index1,2),'xb','MarkerSize',3,'LineWidth',2)
plot(data(index2,1),data(index2,2),'xr','MarkerSize',3,'LineWidth',2)
plot(data(index3,1),data(index3,2),'xg','MarkerSize',3,'LineWidth',2)
xlabel('X axis');
ylabel('Y axis');
title('K-means on Fisher Iris Dataset with 3 Cluster');
hold off
%% ionosphere 2 cluster
clear;
load ionosphere;
x=X(1:end,33);
y=X(1:end,34);
data=x;
data(1:end,2)=y;
%plot the class for 1 and 5 dim
% dataset=X;
% datasetsize=size(dataset);
% lbl=string(Y);
% for i=1:datasetsize(1,1)
% if lbl(i,1)=='g'
%     label(i,1)=1;
% else if lbl(i,1)=='b'
%     label(i,1)=2;
% end;end;end;
% for i=1:datasetsize(1,1)
% if label(i,1)==1
%     plot(dataset(i,33),dataset(i,34),'xb','MarkerSize',3,'LineWidth',2);    hold on;
% else if label(i,1)==2
%     plot(dataset(i,33),dataset(i,34),'xr','MarkerSize',3,'LineWidth',2);    hold on;
% end;end;end;
figure;
[idx1,centers1] = kmeans(data,2);
plot(centers1(1,1),centers1(1,2),'ob','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(2,1),centers1(2,2),'or','MarkerSize',10,'LineWidth',2);
hold on
index1 = find(idx1 == 1);
index2 = find(idx1 == 2);
plot(data(index1,1),data(index1,2),'xb','MarkerSize',3,'LineWidth',2)
plot(data(index2,1),data(index2,2),'xr','MarkerSize',3,'LineWidth',2)
xlabel('X axis');
ylabel('Y axis');
title('K-means on Ionosphere Dataset with 2 Cluster');
hold off
%% blood transfusion
clear;
load ('transfusion.dat');
x=transfusion(1:end,2);
y=transfusion(1:end,4);
data=x;
data(1:end,2)=y;
%plot the class for 1 and 5 dim
dataset=transfusion;
datasetsize=size(dataset);
for i=1:datasetsize(1,1)
if dataset(i,5)==1
    plot(dataset(i,2),dataset(i,4),'xb','MarkerSize',3,'LineWidth',2);    hold on;
else if dataset(i,5)==0
    plot(dataset(i,2),dataset(i,4),'xr','MarkerSize',3,'LineWidth',2);    hold on;
end;end;end;
figure; 
[idx1,centers1] = kmeans(data,2);
plot(centers1(1,1),centers1(1,2),'ob','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(2,1),centers1(2,2),'or','MarkerSize',10,'LineWidth',2);
hold on
index1 = find(idx1 == 1);
index2 = find(idx1 == 2);
plot(data(index1,1),data(index1,2),'xb','MarkerSize',3,'LineWidth',2)
plot(data(index2,1),data(index2,2),'xr','MarkerSize',3,'LineWidth',2)
hold off
%% Data_User_Modeling_Dataset_Hamdi Tolga KAHRAMAN
clear;
load ('Data_User_Modeling_Dataset_Hamdi Tolga KAHRAMAN');
x=Data_User_Modeling_Dataset(1:end,1);
y=Data_User_Modeling_Dataset(1:end,5);
data=x;
data(1:end,2)=y;
%plot the class for 1 and 5 dim
dataset=Data_User_Modeling_Dataset;
datasetsize=size(dataset);
for i=1:datasetsize(1,1)
if dataset(i,6)==1
    plot(dataset(i,1),dataset(i,5),'xb','MarkerSize',3,'LineWidth',2);    hold on;
else if dataset(i,6)==2
    plot(dataset(i,1),dataset(i,5),'xr','MarkerSize',3,'LineWidth',2);    hold on;
else if dataset(i,6)==3
    plot(dataset(i,1),dataset(i,5),'xg','MarkerSize',3,'LineWidth',2);    hold on;
else if dataset(i,6)==4
    plot(dataset(i,1),dataset(i,5),'xc','MarkerSize',3,'LineWidth',2);    hold on;
end;end;end;end;end;
figure;  
[idx1,centers1] = kmeans(data,4);
plot(centers1(1,1),centers1(1,2),'ob','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(2,1),centers1(2,2),'or','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(3,1),centers1(3,2),'go','MarkerSize',10,'LineWidth',2);
hold on
plot(centers1(4,1),centers1(4,2),'co','MarkerSize',10,'LineWidth',2);
hold on
index1 = find(idx1 == 1);
index2 = find(idx1 == 2);
index3 = find(idx1 == 3);
index4 = find(idx1 == 4);
plot(data(index1,1),data(index1,2),'xb','MarkerSize',3,'LineWidth',2)
plot(data(index2,1),data(index2,2),'xr','MarkerSize',3,'LineWidth',2)
plot(data(index3,1),data(index3,2),'xg','MarkerSize',3,'LineWidth',2)
plot(data(index4,1),data(index4,2),'xc','MarkerSize',3,'LineWidth',2)
xlabel('X axis');
ylabel('Y axis');
title('K-means on Data-User-Modeling Dataset with 4 Clusters');
hold off
