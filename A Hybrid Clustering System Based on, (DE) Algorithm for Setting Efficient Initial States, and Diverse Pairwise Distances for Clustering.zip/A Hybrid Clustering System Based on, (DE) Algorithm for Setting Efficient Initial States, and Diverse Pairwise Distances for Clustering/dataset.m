clear;
wine=wine(:,2:14);

scatter(wine(:,1),wine(:,3));
hold on;
scatter(wine(:,4),wine(:,11));
hold on;
scatter(wine(:,1)+5,wine(:,12)+1);
hold on;
scatter(wine(:,4)+10,wine(:,12)+1);

x=wine(:,1);
y=wine(:,3);
x(179:356,1)=wine(:,4);
y(179:356,1)=wine(:,11);
x(357:534,1)=wine(:,1)+5;
y(357:534,1)=wine(:,12)+1;
x(535:712,1)=wine(:,4)+10;
y(535:712,1)=wine(:,12)+1;
% scatter(x,y);
data=x;
data(:,2)=y;
scatter(data(:,1),data(:,2));

