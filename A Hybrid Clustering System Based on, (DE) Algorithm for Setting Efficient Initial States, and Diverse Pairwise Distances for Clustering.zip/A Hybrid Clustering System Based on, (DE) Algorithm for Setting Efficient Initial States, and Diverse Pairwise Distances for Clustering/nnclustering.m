clear;
load fisheriris
x=meas(:,2);
y=meas(:,4);
data=x;
data(:,2)=y;

lbl(1:50,1)=1;
lbl(51:100,1)=2;
lbl(101:150,1)=3;

for i=1:150
if lbl(i,1)==1
    plot(data(i,1),data(i,2),'xb','MarkerSize',3,'LineWidth',2);    hold on;
else if lbl(i,1)==2
    plot(data(i,1),data(i,2),'xr','MarkerSize',3,'LineWidth',2);    hold on;
    else if lbl(i,1)==3
    plot(data(i,1),data(i,2),'xg','MarkerSize',3,'LineWidth',2);    hold on;
end;end;end;end;

