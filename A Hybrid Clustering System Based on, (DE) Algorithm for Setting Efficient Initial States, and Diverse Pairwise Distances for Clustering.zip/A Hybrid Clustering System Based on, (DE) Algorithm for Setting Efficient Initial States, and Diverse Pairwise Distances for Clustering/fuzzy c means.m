clear;
%% random data with 5 cluster
lowerbound = 1;
upperbound = 100;
numberofdata=450;
x = (upperbound-lowerbound).*rand(numberofdata,1) + lowerbound;
y = (upperbound-lowerbound).*rand(numberofdata,1) + lowerbound;
fcmdata(1:numberofdata,1)=x;
fcmdata(1:numberofdata,2)=y;
[centers,U] = fcm(fcmdata,5);
% Classify each data point into the cluster with the largest membership value.
maxU = max(U);
index1 = find(U(1,:) == maxU);
index2 = find(U(2,:) == maxU);
index3 = find(U(3,:) == maxU);
index4 = find(U(4,:) == maxU);
index5 = find(U(5,:) == maxU);
% Plot the clustered data and cluster centers.
plot(fcmdata(index1,1),fcmdata(index1,2),'ob')
hold on
plot(fcmdata(index2,1),fcmdata(index2,2),'or')
hold on
plot(fcmdata(index3,1),fcmdata(index3,2),'gs')
hold on
plot(fcmdata(index4,1),fcmdata(index4,2),'oc')
hold on
plot(fcmdata(index5,1),fcmdata(index5,2),'om')
plot(centers(1,1),centers(1,2),'xb','MarkerSize',15,'LineWidth',3)
plot(centers(2,1),centers(2,2),'xr','MarkerSize',15,'LineWidth',3)
plot(centers(3,1),centers(3,2),'xg','MarkerSize',15,'LineWidth',3)
plot(centers(4,1),centers(4,2),'xc','MarkerSize',15,'LineWidth',3)
plot(centers(5,1),centers(5,2),'xm','MarkerSize',15,'LineWidth',3)
hold off
%% iris 3 cluster
clear;
figure;
load fisheriris;
x=meas(1:end,2);
y=meas(1:end,4);
fcmdata=x;
fcmdata(1:end,2)=y;
[centers,U] = fcm(fcmdata,3);
% Classify each data point into the cluster with the largest membership value.
maxU = max(U);
index1 = find(U(1,:) == maxU);
index2 = find(U(2,:) == maxU);
index3 = find(U(3,:) == maxU);
% Plot the clustered data and cluster centers.
plot(fcmdata(index1,1),fcmdata(index1,2),'xb','MarkerSize',3,'LineWidth',2)
hold on
plot(fcmdata(index2,1),fcmdata(index2,2),'xr','MarkerSize',3,'LineWidth',2)
hold on
plot(fcmdata(index3,1),fcmdata(index3,2),'xg','MarkerSize',3,'LineWidth',2)
plot(centers(1,1),centers(1,2),'ob','MarkerSize',10,'LineWidth',2)
plot(centers(2,1),centers(2,2),'or','MarkerSize',10,'LineWidth',2)
plot(centers(3,1),centers(3,2),'go','MarkerSize',10,'LineWidth',2)
xlabel('X axis');
ylabel('Y axis');
title('Fuzzy C-Means on Fisher Iris Dataset with 3 Cluster');
hold off
%% ionosphere 2 cluster
clear;
figure;
load ionosphere;
x=X(1:end,33);
y=X(1:end,34);
fcmdata=x;
fcmdata(1:end,2)=y;
[centers,U] = fcm(fcmdata,2);
% Classify each data point into the cluster with the largest membership value.
maxU = max(U);
index1 = find(U(1,:) == maxU);
index2 = find(U(2,:) == maxU);
% Plot the clustered data and cluster centers.
plot(fcmdata(index1,1),fcmdata(index1,2),'or','MarkerSize',3,'LineWidth',2)
hold on
plot(fcmdata(index2,1),fcmdata(index2,2),'ob','MarkerSize',3,'LineWidth',2)
plot(centers(1,1),centers(1,2),'or','MarkerSize',10,'LineWidth',2)
plot(centers(2,1),centers(2,2),'ob','MarkerSize',10,'LineWidth',2)
xlabel('X axis');
ylabel('Y axis');
title('GGM on Ionosphere Dataset with 2 Cluster');
hold off
%% blood transfusion 2 cluster
clear;
figure;
load ('transfusion.dat');
x=transfusion(1:end,2);
y=transfusion(1:end,4);
fcmdata=x;
fcmdata(1:end,2)=y;
[centers,U] = fcm(fcmdata,2);
% Classify each data point into the cluster with the largest membership value.
maxU = max(U);
index1 = find(U(1,:) == maxU);
index2 = find(U(2,:) == maxU);
% Plot the clustered data and cluster centers.
plot(fcmdata(index1,1),fcmdata(index1,2),'ob')
hold on
plot(fcmdata(index2,1),fcmdata(index2,2),'or')
plot(centers(1,1),centers(1,2),'xb','MarkerSize',15,'LineWidth',3)
plot(centers(2,1),centers(2,2),'xr','MarkerSize',15,'LineWidth',3)
hold off
%% Data_User_Modeling_Dataset_Hamdi Tolga KAHRAMAN
clear;
load ('Data_User_Modeling_Dataset_Hamdi Tolga KAHRAMAN');
x=Data_User_Modeling_Dataset(1:end,1);
y=Data_User_Modeling_Dataset(1:end,5);
fcmdata=x;
fcmdata(1:end,2)=y;
[centers,U] = fcm(fcmdata,4);
% Classify each data point into the cluster with the largest membership value.
maxU = max(U);
index1 = find(U(1,:) == maxU);
index2 = find(U(2,:) == maxU);
index3 = find(U(3,:) == maxU);
index4 = find(U(4,:) == maxU);
% Plot the clustered data and cluster centers.
plot(fcmdata(index1,1),fcmdata(index1,2),'xb','MarkerSize',3,'LineWidth',2)
hold on
plot(fcmdata(index2,1),fcmdata(index2,2),'xr','MarkerSize',3,'LineWidth',2)
hold on
plot(fcmdata(index3,1),fcmdata(index3,2),'xg','MarkerSize',3,'LineWidth',2)
hold on
plot(fcmdata(index4,1),fcmdata(index4,2),'xc','MarkerSize',3,'LineWidth',2)
hold on
plot(centers(1,1),centers(1,2),'ob','MarkerSize',10,'LineWidth',2)
plot(centers(2,1),centers(2,2),'or','MarkerSize',10,'LineWidth',2)
plot(centers(3,1),centers(3,2),'og','MarkerSize',10,'LineWidth',2)
plot(centers(4,1),centers(4,2),'oc','MarkerSize',10,'LineWidth',2)
xlabel('X axis');
ylabel('Y axis');
title('Fuzzy C-Means on Data-User-Modeling Dataset with 4 Clusters');
hold off