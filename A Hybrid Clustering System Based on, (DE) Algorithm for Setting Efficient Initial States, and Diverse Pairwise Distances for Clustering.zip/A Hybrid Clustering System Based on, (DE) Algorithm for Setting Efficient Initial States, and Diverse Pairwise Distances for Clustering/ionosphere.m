clear;
load ionosphere;
xxx=X(1:end,33);
yyy=X(1:end,34);
data=xxx;
data(1:end,2)=yyy;
numberofdata=351;
% scatter(x,y);
%% calling de for finding n initial clusters
de;
initialclusters=BestSol.Position;
% figure; plot(data(:,1),data(:,2),'rs','LineWidth',1,'MarkerSize',10,'MarkerEdgeColor','g','MarkerFaceColor',[1 0 0]);hold on;
% plot(initialclusters(:,1),initialclusters(:,2),'go','LineWidth',1,'MarkerSize',10,'MarkerEdgeColor','b','MarkerFaceColor',[0 0 1]);
% title('Founded Initial Clusters With Differential Evolution Algorithm');

%% Finding m farest sampeles in relation to any n initial clusters
clear i;clear j;clear cluster;clear dist;clear sortdistance;clear maxdistancevalue;clear maxdistanceindex; clear newfar;
for i=1:2 %number of clusters
% figure;
plot(data(:,1),data(:,2),'rs','LineWidth',1,'MarkerSize',10,'MarkerEdgeColor','g','MarkerFaceColor',[1 0 0]);hold on;
for j=1:5 %number of farest samples from cluster
cluster(i,:)=initialclusters(i,:);
dist=pdist2(cluster(i,:),data);
sortdistance=sort(dist)';
maxdistancevalue=sortdistance(round(numberofdata-j),1);
maxdistanceindex=find(dist==maxdistancevalue);
newfar(j,1:2)=data(maxdistanceindex(1,1),:);
plot(initialclusters(i,1),initialclusters(i,2),'*','LineWidth',1,'MarkerSize',20,'MarkerEdgeColor','b','MarkerFaceColor',[0 0 1]);hold on; 
plot(newfar(j,1),newfar(j,2),'go','LineWidth',1,'MarkerSize',10,'MarkerEdgeColor','b','MarkerFaceColor',[0 0 1]);hold on;
end;
aaa=sum(newfar(1:end,1))/5;
bbb=sum(newfar(1:end,2))/5;
plot(aaa,bbb,'o','LineWidth',1,'MarkerSize',10,'MarkerEdgeColor','[1 0 1]','MarkerFaceColor',[1 0 1]);hold on;
aaabbb(i,1)=aaa;
aaabbb(i,2)=bbb;
end;
figure;
plot(data(:,1),data(:,2),'rs','LineWidth',1,'MarkerSize',10,'MarkerEdgeColor','g','MarkerFaceColor',[1 0 0]);hold on;
for i=1:2
plot(aaabbb(i,1),aaabbb(i,2),'o','LineWidth',1,'MarkerSize',10,'MarkerEdgeColor','[1 0 1]','MarkerFaceColor',[1 0 1]);hold on;
end;
%% first with euclideandistance
euclideandistance = pdist2(aaabbb,data)';
sorteuclideandistance=sort(euclideandistance);

clear sample; clear cluster;
sss=size(euclideandistance);
for i=1:sss(1:1)
[sample(i)  cluster(i)]=min(euclideandistance(i,:));
end;
sample=sample';
cluster=cluster';
%%% cluster1
figure;
for i=1:sss(1:1)
    if cluster(i)==1
        cluster1(i,1:2)=data(i,1:2);
        plot(data(i,1),data(i,2),'go','LineWidth',1,'MarkerSize',7,...
    'MarkerEdgeColor',[1 1 0],'MarkerFaceColor',[1 0 0]);hold on;
    end;
end;
plot(aaabbb(1,1),aaabbb(1,2),'*','LineWidth',1,'MarkerSize',15,...
    'MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0]);hold on;
clear L;

L = cluster1(cluster1~=0); sizel=size(L); sizel=sizel(1:1); sizel=sizel/2;
for i=1: sizel
    cluster11(i,1)=L(i,1);
end;
counter=1;
for i=round(sizel+1): sizel*2
        cluster11(counter,2)=L(i,1);
        counter=counter+1;
end;
temp1=sum(cluster11(1:end,1))/sizel;
temp2=sum(cluster11(1:end,2))/sizel;
newmeancluster1=temp1;   newmeancluster1(1,2)=temp2;
plot(newmeancluster1(1,1),newmeancluster1(1,2),'o','LineWidth',1,'MarkerSize',20,...
    'MarkerEdgeColor','[1 0 1]','MarkerFaceColor',[1 0 1]);hold on;
%%%%%%%%%%%%%%%   cluster2
for i=1:sss(1:1)
    if cluster(i)==2
                cluster2(i,1:2)=data(i,1:2);
        plot(data(i,1),data(i,2),'go','LineWidth',1,'MarkerSize',7,...
    'MarkerEdgeColor',[1 1 0],'MarkerFaceColor',[0 1 0]);hold on;
    end;
end;
plot(aaabbb(2,1),aaabbb(2,2),'*','LineWidth',1,'MarkerSize',15,...
    'MarkerEdgeColor',[0 1 0],'MarkerFaceColor',[0 1 0]);hold on;
clear L;

L = cluster2(cluster2~=0); sizel=size(L); sizel=sizel(1:1); sizel=sizel/2;
for i=1: sizel
    cluster22(i,1)=L(i,1);
end;
counter=1;
for i=round(sizel+1): sizel*2
        cluster22(counter,2)=L(i,1);
        counter=counter+1;
end;
temp1=sum(cluster22(1:end,1))/sizel;
temp2=sum(cluster22(1:end,2))/sizel;
newmeancluster2=temp1;   newmeancluster2(1,2)=temp2;
plot(newmeancluster2(1,1),newmeancluster2(1,2),'o','LineWidth',1,'MarkerSize',20,...
    'MarkerEdgeColor','[1 0 1]','MarkerFaceColor',[1 0 1]);hold on;



%% second with cityblockdistance
clear newmean;
newmean=newmeancluster1; newmean(2,1:2)=newmeancluster2; 
% newmean(3,1:2)=newmeancluster3;

% cityblockdistance
clear euclideandistance;
euclideandistance = pdist2(newmean,data,'cityblock')';

clear sample; clear cluster;
sss=size(euclideandistance);
for i=1:sss(1:1)
[sample(i)  cluster(i)]=min(euclideandistance(i,:));
end;
sample=sample';
cluster=cluster';
%%% cluster1
clear cluster1;
figure;
for i=1:sss(1:1)
    if cluster(i)==1
        cluster1(i,1:2)=data(i,1:2);
        plot(data(i,1),data(i,2),'go','LineWidth',1,'MarkerSize',7,...
    'MarkerEdgeColor',[1 1 0],'MarkerFaceColor',[1 0 0]);hold on;
% xlim([0 100]);
% ylim([0 100]);
    end;
end;
plot(newmean(1,1),newmean(1,2),'*','LineWidth',1,'MarkerSize',15,...
    'MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0]);hold on;
clear L;

L = cluster1(cluster1~=0); sizel=size(L); sizel=sizel(1:1); sizel=sizel/2;
for i=1: sizel
    cluster11(i,1)=L(i,1);
end;
counter=1;
for i=round(sizel+1): sizel*2
        cluster11(counter,2)=L(i,1);
        counter=counter+1;
end;
clear temp1;clear temp2;clear newmeancluster1;
temp1=sum(cluster11(1:end,1))/sizel;
temp2=sum(cluster11(1:end,2))/sizel;
newmeancluster1=temp1;   newmeancluster1(1,2)=temp2;
plot(newmeancluster1(1,1),newmeancluster1(1,2),'o','LineWidth',1,'MarkerSize',20,...
    'MarkerEdgeColor','[1 0 1]','MarkerFaceColor',[1 0 1]);hold on;

%%%%%%%%%%%%%%%   cluster2
clear cluster2;
for i=1:sss(1:1)
    if cluster(i)==2
                cluster2(i,1:2)=data(i,1:2);
        plot(data(i,1),data(i,2),'go','LineWidth',1,'MarkerSize',7,...
    'MarkerEdgeColor',[1 1 0],'MarkerFaceColor',[0 1 0]);hold on;
% xlim([0 100]);
% ylim([0 100]);
    end;
end;
plot(newmean(2,1),newmean(2,2),'*','LineWidth',1,'MarkerSize',15,...
    'MarkerEdgeColor',[0 1 0],'MarkerFaceColor',[0 1 0]);hold on;
clear L;

L = cluster2(cluster2~=0); sizel=size(L); sizel=sizel(1:1); sizel=sizel/2;
for i=1: sizel
    cluster22(i,1)=L(i,1);
end;
counter=1;
for i=round(sizel+1): sizel*2
        cluster22(counter,2)=L(i,1);
        counter=counter+1;
end;clear temp1;clear temp2;clear newmeancluster2;
temp1=sum(cluster22(1:end,1))/sizel;
temp2=sum(cluster22(1:end,2))/sizel;
newmeancluster2=temp1;   newmeancluster2(1,2)=temp2;
plot(newmeancluster2(1,1),newmeancluster2(1,2),'o','LineWidth',1,'MarkerSize',20,...
    'MarkerEdgeColor','[1 0 1]','MarkerFaceColor',[1 0 1]);hold on;





%% fourth with chebychev
clear newmean;
newmean=newmeancluster1; newmean(2,1:2)=newmeancluster2; 
% newmean(3,1:2)=newmeancluster3;

% cityblockdistance
clear euclideandistance;
euclideandistance = pdist2(newmean,data,'chebychev')';

clear sample; clear cluster;
sss=size(euclideandistance);
for i=1:sss(1:1)
[sample(i)  cluster(i)]=min(euclideandistance(i,:));
end;
sample=sample';
cluster=cluster';
%%% cluster1
clear cluster1;
figure;
for i=1:sss(1:1)
    if cluster(i)==1
        cluster1(i,1:2)=data(i,1:2);
        plot(data(i,1),data(i,2),'xb','LineWidth',2,'MarkerSize',3); hold on;
xlabel('X axis');
ylabel('Y axis');
title('Proposed Method on Ionosphere Dataset with 2 Cluster');
    end;
end;
% plot(newmean(1,1),newmean(1,2),'*','LineWidth',1,'MarkerSize',15,...
%     'MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0]);hold on;
clear L;

L = cluster1(cluster1~=0); sizel=size(L); sizel=sizel(1:1); sizel=sizel/2;
for i=1: sizel
    cluster11(i,1)=L(i,1);
end;
counter=1;
for i=round(sizel+1): sizel*2
        cluster11(counter,2)=L(i,1);
        counter=counter+1;
end;clear temp1;clear temp2;clear newmeancluster1;
temp1=sum(cluster11(1:end,1))/sizel;
temp2=sum(cluster11(1:end,2))/sizel;
newmeancluster1=temp1;   newmeancluster1(1,2)=temp2;
plot(newmeancluster1(1,1),newmeancluster1(1,2),'ob','LineWidth',2,'MarkerSize',10);hold on;

%%%%%%%%%%%%%%%   cluster2
clear cluster2;
for i=1:sss(1:1)
    if cluster(i)==2
                cluster2(i,1:2)=data(i,1:2);
        plot(data(i,1),data(i,2),'xr','LineWidth',2,'MarkerSize',3);hold on;
    end;
end;
% plot(newmean(2,1),newmean(2,2),'*','LineWidth',1,'MarkerSize',15,...
%     'MarkerEdgeColor',[0 1 0],'MarkerFaceColor',[0 1 0]);hold on;
clear L;

L = cluster2(cluster2~=0); sizel=size(L); sizel=sizel(1:1); sizel=sizel/2;
for i=1: sizel
    cluster22(i,1)=L(i,1);
end;
counter=1;
for i=round(sizel+1): sizel*2
        cluster22(counter,2)=L(i,1);
        counter=counter+1;
end;clear temp1;clear temp2;clear newmeancluster2;
temp1=sum(cluster22(1:end,1))/sizel;
temp2=sum(cluster22(1:end,2))/sizel;
newmeancluster2=temp1;   newmeancluster2(1,2)=temp2;
plot(newmeancluster2(1,1),newmeancluster2(1,2),'or','LineWidth',2,'MarkerSize',10);hold on;
