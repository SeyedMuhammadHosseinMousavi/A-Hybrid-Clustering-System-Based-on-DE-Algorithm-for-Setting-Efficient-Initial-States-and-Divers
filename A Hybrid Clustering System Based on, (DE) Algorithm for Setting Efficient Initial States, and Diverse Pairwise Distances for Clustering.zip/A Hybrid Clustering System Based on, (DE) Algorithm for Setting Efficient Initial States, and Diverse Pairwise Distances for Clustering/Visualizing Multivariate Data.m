clear;
load carbig
X = [MPG,Acceleration,Displacement,Weight,Horsepower];
varNames = {'MPG'; 'Acceleration'; 'Displacement'; 'Weight'; 'Horsepower'};
figure
gplotmatrix(X,[],Cylinders,['c' 'b' 'm' 'g' 'r'],[],[],false);
text([.08 .24 .43 .66 .83], repmat(-.1,1,5), varNames, 'FontSize',8);
text(repmat(-.12,1,5), [.86 .62 .41 .25 .02], varNames, 'FontSize',8, 'Rotation',90);
%%
% Parallel Coordinates Plots
%  Each observation is represented in the plot as a series of connected line segments.
figure;
Cyl468 = ismember(Cylinders,[4 6 8]);
parallelcoords(X(Cyl468,:), 'group',Cylinders(Cyl468), ...
               'standardize','on', 'labels',varNames)
           figure;
% Andrews Plots
% Another similar type of multivariate visualization is the Andrews plot. This plot represents each observation 
% as a smooth function over the interval [0,1].
Cyl468 = ismember(Cylinders,[4 6 8]);
andrewsplot(X(Cyl468,:), 'group',Cylinders(Cyl468), 'standardize','on')